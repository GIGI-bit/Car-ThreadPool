﻿using Car_HW.Model;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace Car_HW.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Car> _cars;
        private bool _isSingle;
        private bool _isMulti;
        private DispatcherTimer dispatcherTimer;
        private int secondsElapsed;
        private string _timer;
        public bool IsSingle { get => _isSingle; set { _isSingle = value; OnPropertyChanged(); } }
        public bool IsMulti { get => _isMulti; set { _isMulti = value; OnPropertyChanged(); } }
        public ObservableCollection<Car> Cars { get { return _cars; } set { _cars = value; OnPropertyChanged(); } }
        public ICommand StartButton { get; set; }
        public string Timer { get => _timer; set {  _timer = value; OnPropertyChanged(); } }
        
        public MainViewModel()
        {
            Cars = new ObservableCollection<Car>();
            StartButton = new RelayCommand<object>(startExec);
            Timer = "00:00:00";
            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Interval = TimeSpan.FromSeconds(1); 
            dispatcherTimer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            secondsElapsed++;
            Application.Current.Dispatcher.Invoke(() => { Timer = TimeSpan.FromSeconds(secondsElapsed).ToString(@"hh\:mm\:ss"); });

        }

        private void startExec(object parameter)
        {
            if (IsSingle)
            {
                string address;
                Task.Run(() =>
                {
                    dispatcherTimer.Start();
                    var thread = new Thread(() =>
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            string baseDirectory = Directory.GetCurrentDirectory();
                            baseDirectory = baseDirectory.Substring(0, baseDirectory.IndexOf("bin"));
                            address =Path.Combine(baseDirectory, "JsonFiles","car" + i.ToString() + ".json");
                            if (File.Exists(address))
                            {
                                try
                                {
                                    var list = readFromJson(address);
                                    foreach (var item in list)
                                    {
                                        Application.Current.Dispatcher.Invoke(() =>
                                            {
                                                Cars.Add(item);
                                                
                                            });
                                    }
                                    
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                dispatcherTimer.Stop();
                            }
                        }
                    });
                    thread.Start();
                });

            }
            else if (IsMulti)
            {
                string address;
                dispatcherTimer.Start();
                for (global::System.Int32 i = 0; i < 5; i++)
                {
                    string baseDirectory = Directory.GetCurrentDirectory();
                    baseDirectory = baseDirectory.Substring(0, baseDirectory.IndexOf("bin"));
                    address = Path.Combine(baseDirectory, "JsonFiles", "car" + i.ToString() + ".json");
                    if (File.Exists(address))
                    {
                        try
                        {
                           
                            var thread = new Thread(() =>
                            {
                                var list = readFromJson(address);
                                foreach (var item in list)
                                {
                                    Application.Current.Dispatcher.Invoke(() =>
                                    {
                                        Cars.Add(item);
                                    });
                                }
                            });
                            thread.Start();
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                dispatcherTimer.Stop();
            }
            
        }

        private ObservableCollection<Car> readFromJson(string fileName)
        {
            var json = File.ReadAllText(fileName);
            ObservableCollection<Car> cars = JsonConvert.DeserializeObject<ObservableCollection<Car>>(json);
            return cars;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
