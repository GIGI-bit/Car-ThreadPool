﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_HW.Model
{
    public class Car
    {
        private string _vendor;
        public string Vendor
        {
            get { return _vendor; }
            set
            {
                if (value == null)
                    throw new Exception("Vendor cannot be null");
                _vendor = value;
            }
        }

        private string _model;
        public string Model
        {
            get { return _model; }
            set
            {
                if (value == null)
                    throw new Exception("Model cannot be null");
                _model = value;
            }
        }

        private int _year;
        public int Year
        {
            get { return _year; }
            set
            {
                if (value == null)
                    throw new Exception("Year cannot be null");
                _year = value;
            }
        }

        private string _imagePath;
        public string ImagePath
        {
            get { return _imagePath; }
            set
            {
                if (value == null)
                    _imagePath = "C:\\Users\\Sevgi\\source\\repos\\Car_HW\\Car_HW\\Medias\\car.png";
                _imagePath = value; }
        }

        public Car(string vendor, string model, int year, string imagePath)
        {
            Vendor = vendor;
            Model = model;
            Year = year;
            ImagePath = imagePath;
        }
        public Car()
        {

        }
    }
}
