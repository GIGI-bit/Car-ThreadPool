﻿using Car_HW.Model;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Car_HW.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Car> _cars;
        private bool _isSingle;
        private bool _isMulti;
        public bool IsSingle { get => _isSingle; set { _isSingle = value; OnPropertyChanged(); } }
        public bool IsMulti { get => _isMulti; set { _isMulti = value; OnPropertyChanged(); } }
        public ObservableCollection<Car> Cars { get { return _cars; } set { _cars = value; OnPropertyChanged(); } }
        public ICommand StartButton { get; set; }

        public MainViewModel()
        {
            Cars = new ObservableCollection<Car>();
            StartButton = new RelayCommand<object>(startExec);
        }

        private void startExec(object parameter)
        {
            if (IsSingle)
            {
                string address;
                Task.Run(() =>
                {

                    var thread = new Thread(() =>
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            address = $"C:\\Users\\Sevgi\\source\\repos\\Car_HW\\Car_HW\\JsonFiles\\{"car" + i.ToString() + ".json"}";
                            if (File.Exists(address))
                            {
                                try
                                {
                                    var list = readFromJson(address);
                                    foreach (var item in list)
                                    {
                                        Application.Current.Dispatcher.Invoke(() =>
                                            {
                                                Cars.Add(item);
                                            });
                                    }
                                
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                            }
                        }
                    });
                    thread.Start();
                });
                
            }

        }

        private ObservableCollection<Car> readFromJson(string fileName)
        {
            var json = File.ReadAllText(fileName);
            ObservableCollection<Car> cars = JsonConvert.DeserializeObject<ObservableCollection<Car>>(json);
            return cars;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
